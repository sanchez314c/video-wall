# VideoWall - Linux Version

VideoWall is a multi-stream video wall application that displays multiple M3U8 streams simultaneously.

## Quick Start

### Option 1: Build from Source
1. Install dependencies:
   ```bash
   # Ubuntu/Debian:
   sudo apt-get install python3-pyqt5 python3-pyqt5.qtmultimedia

   # Or run the install script:
   ./install.sh
   ```

2. Build the application:
   ```bash
   ./build-on-linux.sh
   ```

3. Run:
   ```bash
   ./run-VideoWall.sh
   ```

### Option 2: Use Pre-built Binary
If you have a pre-built binary:
1. Run the installer to set up dependencies:
   ```bash
   ./install.sh
   ```

2. Run the application:
   ```bash
   ./run-VideoWall.sh
   ```

## System Requirements

- Linux (x86_64)
- Qt5 (version 5.12 or higher)
- PyQt5
- PyQt5Multimedia
- GStreamer (for optimal video playback)

## Dependencies Installation

### Ubuntu/Debian:
```bash
sudo apt-get install libqt5multimedia5 libqt5multimediawidgets5 \
  libqt5widgets5 libqt5gui5 libqt5core5a libqt5network5 \
  gstreamer1.0-libav gstreamer1.0-plugins-ugly
```

### Fedora/CentOS:
```bash
sudo dnf install qt5-qtmultimedia qt5-qtbase-gui \
  qt5-base qt5-qtnetworkauth qt5-qtsvg
```

### Arch Linux:
```bash
sudo pacman -S qt5-multimedia qt5-base qt5-networkauth qt5-svg
```

## Configuration

The application loads M3U8 streams from:
- `m3u8-hosts.m3u8` (in the application directory)

To customize streams, edit this file with your M3U8 URLs.

## Troubleshooting

### Application won't start:
1. Check if all Qt5 dependencies are installed
2. Try running with debug output: `./VideoWall 2>&1`
3. Ensure the binary is executable: `chmod +x VideoWall`

### No video playback:
1. Install GStreamer plugins (see dependencies)
2. Check network connectivity
3. Verify M3U8 URLs are valid

### Performance issues:
1. Reduce number of simultaneous streams
2. Check system resources (CPU, RAM, GPU)
3. Update graphics drivers

## License

Please refer to the main project repository for license information.
