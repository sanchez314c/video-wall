#!/bin/bash

# Build VideoWall on Linux
# Run this script on a Linux machine to build the binary

set -e

echo "Building VideoWall for Linux..."

# Check if running on Linux
if [ "$(uname)" != "Linux" ]; then
    echo "Error: This script must be run on Linux"
    exit 1
fi

# Install dependencies (Ubuntu/Debian)
if command -v apt-get &> /dev/null; then
    echo "Installing dependencies with apt..."
    sudo apt-get update
    sudo apt-get install -y \
        python3-pyqt5 \
        python3-pyqt5.qtmultimedia \
        python3-pip \
        build-essential
fi

# Install dependencies (Fedora/CentOS)
if command -v dnf &> /dev/null; then
    echo "Installing dependencies with dnf..."
    sudo dnf install -y \
        python3-qt5 \
        python3-pip \
        gcc
fi

# Install Python dependencies
echo "Installing Python dependencies..."
pip3 install pyinstaller PyQt5 PyQt5Multimedia requests

# Build
echo "Building with PyInstaller..."
pyinstaller VideoWall-linux-portable.spec --clean --noconfirm

# Create package
echo "Creating package..."
tar -czf VideoWall-Linux-x64.tar.gz dist/VideoWall/

echo "Build complete! Package: VideoWall-Linux-x64.tar.gz"
