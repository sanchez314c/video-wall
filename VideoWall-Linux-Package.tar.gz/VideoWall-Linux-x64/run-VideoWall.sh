#!/bin/bash

# Run VideoWall on Linux

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Set environment variables
export QT_PLUGIN_PATH="$SCRIPT_DIR/plugins:$QT_PLUGIN_PATH"
export LD_LIBRARY_PATH="$SCRIPT_DIR:$LD_LIBRARY_PATH"

# Run the application
if [ -f "$SCRIPT_DIR/VideoWall" ]; then
    cd "$SCRIPT_DIR"
    ./VideoWall "$@"
else
    echo "Error: VideoWall binary not found"
    echo "Please build VideoWall first using: ./build-on-linux.sh"
    exit 1
fi
