#!/bin/bash

# Installation script for VideoWall on Linux
# Run this after extracting the VideoWall binary package

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_info "Installing VideoWall for Linux..."

# Check if running on Linux
if [ "$(uname)" != "Linux" ]; then
    print_error "This installer is for Linux only"
    exit 1
fi

# Detect package manager
if command -v apt-get &> /dev/null; then
    PKG_MANAGER="apt"
    print_info "Detected Debian/Ubuntu-based system"
elif command -v dnf &> /dev/null; then
    PKG_MANAGER="dnf"
    print_info "Detected Fedora/CentOS-based system"
elif command -v pacman &> /dev/null; then
    PKG_MANAGER="pacman"
    print_info "Detected Arch-based system"
else
    print_warning "Unknown package manager. You may need to install dependencies manually."
fi

# Install system dependencies
case $PKG_MANAGER in
    apt)
        print_info "Installing Qt5 dependencies..."
        sudo apt-get update
        sudo apt-get install -y \
            libqt5multimedia5 \
            libqt5multimediawidgets5 \
            libqt5widgets5 \
            libqt5gui5 \
            libqt5core5a \
            libqt5network5 \
            libqt5svg5 \
            libqt5opengl5 \
            libqt5printsupport5
        ;;
    dnf)
        print_info "Installing Qt5 dependencies..."
        sudo dnf install -y \
            qt5-qtmultimedia \
            qt5-qtbase-gui \
            qt5-qtbase \
            qt5-qtnetworkauth \
            qt5-qtsvg
        ;;
    pacman)
        print_info "Installing Qt5 dependencies..."
        sudo pacman -S --noconfirm \
            qt5-multimedia \
            qt5-base \
            qt5-networkauth \
            qt5-svg
        ;;
esac

# Install optional dependencies for better video support
print_warning "Installing optional GStreamer dependencies for better video support..."
case $PKG_MANAGER in
    apt)
        sudo apt-get install -y \
            gstreamer1.0-libav \
            gstreamer1.0-plugins-ugly \
            gstreamer1.0-plugins-bad || true
        ;;
    dnf)
        sudo dnf install -y \
            gstreamer1-libav \
            gstreamer1-plugins-ugly \
            gstreamer1-plugins-bad-freeworld || true
        ;;
esac

# Create desktop entry
print_info "Creating desktop shortcut..."
mkdir -p ~/.local/share/applications
cat > ~/.local/share/applications/VideoWall.desktop << EOL
[Desktop Entry]
Version=1.0
Type=Application
Name=VideoWall
Comment=Multi-stream video wall application
Exec=$(pwd)/VideoWall/run-VideoWall.sh
Icon=$(pwd)/VideoWall/icons/icon.png
Terminal=false
Categories=AudioVideo;Video;
EOL

update-desktop-database ~/.local/share/applications/ 2>/dev/null || true

print_success "Installation complete!"
print_info "To run VideoWall:"
print_info "  1. Navigate to the VideoWall directory"
print_info "  2. Run: ./run-VideoWall.sh"
print_info ""
print_info "Or use the application menu shortcut"
